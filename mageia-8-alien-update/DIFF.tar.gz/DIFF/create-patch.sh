#!/bin/bash

diff -u a/Alien/Package/Deb.pm b/Alien/Package/Deb.pm > Deb.pm.patch